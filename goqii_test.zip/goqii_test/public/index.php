<?php
// Include database connection and User class
require_once '../config/database.php';
require_once '../models/user.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Handle different HTTP methods
switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        // Create User
        $data = json_decode(file_get_contents("php://input"));
        $user->name = $data->name;
        $user->email = $data->email;
        $user->password = password_hash($data->password, PASSWORD_DEFAULT);
        $user->dob = $data->dob;
        
        if ($user->create()) {
            echo json_encode(['message' => 'User created successfully.']);
        } else {
            echo json_encode(['message' => 'Failed to create user.']);
        }
        break;

    case 'GET':
        // Get all users
        $stmt = $user->read();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($users);
        break;

    case 'PUT':
        // Update user
        $data = json_decode(file_get_contents("php://input"));
        $user->id = $data->id;
        $user->name = $data->name;
        $user->email = $data->email;
        $user->password = password_hash($data->password, PASSWORD_DEFAULT);
        $user->dob = $data->dob;

        if ($user->update()) {
            echo json_encode(['message' => 'User updated successfully.']);
        } else {
            echo json_encode(['message' => 'Failed to update user.']);
        }
        break;

    case 'DELETE':
        // Delete user
        $data = $_GET['id'];
        if ($user->delete($data)) {
            echo json_encode(['message' => 'User deleted successfully.']);
        } else {
            echo json_encode(['message' => 'Failed to delete user.']);
        }
        break;

    default:
        echo json_encode(['message' => 'Invalid request method']);
}
