<?php
include('../config/database.php');

class User {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create User
    public function createUser($name, $email, $password, $dob) {
        // Use '?' placeholders instead of named placeholders
        $sql = "INSERT INTO users (name, email, password, dob) VALUES (?, ?, ?, ?)";
        
        // Prepare the statement
        $stmt = $this->conn->prepare($sql);
    
        // Hash the password before binding it to the query
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Bind the parameters with 'ssss' indicating that all are strings
        $stmt->bind_param("ssss", $name, $email, $hashedPassword, $dob);
    
        // Execute the statement and return true if successful
        if ($stmt->execute()) {
            return true;
        }
    
        return false;
    }
    

    // Read All Users
    public function getUsers() {
        $sql = "SELECT * FROM users";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();

        // Get the result set
        $result = $stmt->get_result();

        // Initialize an array to store the results
        $users = [];

        // Fetch all rows into the array
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }

        // Return the array of users
        return $users;
    }

    // Get a single User
    public function getUser($id) {
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($sql);

        // Bind the parameter (type 'i' for integer)
        $stmt->bind_param('i', $id);

        // Execute the query
        $stmt->execute();

        // Get the result
        $result = $stmt->get_result();

        // Fetch the user data as an associative array
        return $result->fetch_assoc();
    }

    // Update User
    public function updateUser($id, $name, $email, $dob) {
        
        $sql = "UPDATE users SET name = ?, email = ?, dob = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $email, $dob, $id);

        return $stmt->execute();
    }

    // Delete User
    public function deleteUser($id) {
        // Ensure ID is a valid integer
        $id = intval($id);
    
        // Prepare DELETE query
        $query = "DELETE FROM users WHERE id = ?";
        
        // Prepare statement
        $stmt = $this->conn->prepare($query);
        if ($stmt === false) {
            error_log('Statement prepare failed: ' . $this->conn->error); // Log SQL preparation failure
            return false;
        }
    
        // Bind parameter to statement
        $stmt->bind_param("i", $id); // "i" indicates integer type for ID
    
        // Execute the statement
        if ($stmt->execute()) {
            // Check the affected rows
            if ($stmt->affected_rows > 0) {
                // echo '1';exit;
                $stmt->close();
                return true;
            } else {
                // echo '0';exit;
                // Log if no rows were affected
                error_log('No rows affected for ID: ' . $id . '. This might mean the user does not exist.');
                $stmt->close();
                return false;
            }
        } else {
            // echo '00';exit;
            // Log the execution error
            error_log('Execute failed for DELETE statement: ' . $stmt->error);
            $stmt->close();
            return false;
        }
    }    
    
}
?>
