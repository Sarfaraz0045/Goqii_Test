<?php
header('Content-Type: application/json');
include('../config/database.php');
include('../models/user.php');

$method = $_SERVER['REQUEST_METHOD'];
$user = new User($conn);

switch ($method) {
    case 'POST':
        // Create a new user
        if (isset($_POST['name'], $_POST['email'], $_POST['password'])) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $dob = date('Y-m-d', strtotime($_POST['dob']));

            if ($user->createUser($name, $email, $password, $dob)) {
                header("Location: ../res/index.php");
                // echo json_encode(["message" => "User created successfully"]);
            } else {
                echo json_encode(["message" => "Failed to create user"]);
            }
        } else {
            echo json_encode(["message" => "Invalid input"]);
        }
        break;

    case 'GET':
        if (isset($_GET['id'])) {
            // Get a single user
            $id = $_GET['id'];
            $data = $user->getUser($id);
            if ($data) {
                echo json_encode($data);
            } else {
                echo json_encode(["message" => "User not found"]);
            }
        } else {
            // Get all users
            $data = $user->getUsers();
            echo json_encode($data);
        }
        break;

        case 'PUT':
            // Read raw input data
            parse_str(file_get_contents("php://input"), $_PUT);
    
            // Validate required fields
            if (isset($_PUT['id'], $_PUT['name'], $_PUT['email'], $_PUT['dob'])) {
                $id = $_PUT['id'];
                $name = $_PUT['name'];
                $email = $_PUT['email'];
                $dob = $_PUT['dob'];
                
                // Call the updateUser method from the User class
                if ($user->updateUser($id, $name, $email, $dob)) {
                    echo json_encode(["status" => "success", "message" => "User updated successfully", "id" => $id, "name" => $name, "email" => $email, "dob" => $dob]);
                } else {
                    echo json_encode(["status" => "error", "message" => "Failed to update user"]);
                }
            } else {
                echo json_encode(["status" => "error", "message" => "Invalid input"]);
            }
            break;   

    case 'DELETE':
        // Delete user
        $input = json_decode(file_get_contents('php://input'), true);
        if (isset($input['id'])) {
            $id = $input['id'];
            $check_con = $user->deleteUser($id);
            // echo $check_con;exit;
            // Attempt to delete the user
            if ($check_con == 1) {
                echo json_encode(["success" => true, "message" => "User deleted successfully"]);
            } else {
                echo json_encode(["success" => false, "message" => "Failed to delete user"]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Invalid input"]);
        }
        break;

    default:
        echo json_encode(["message" => "Method not allowed"]);
        break;
}
?>
