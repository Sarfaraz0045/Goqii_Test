
const apiUrl = 'http://localhost/goqii_test/api/user.php';
// console.log(apiUrl);
// Get elements from the DOM
const userList = document.getElementById('userList');
const addUserBtn = document.getElementById('addUserBtn');
const userFormContainer = document.getElementById('userFormContainer');
const userForm = document.getElementById('userForm');
const submitBtn = document.getElementById('submitBtn');
const formTitle = document.getElementById('formTitle');
const userIdInput = document.getElementById('userId');

// Fetch and display users
function fetchUsers() {
    fetch(apiUrl, {
        method: 'GET',
        headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Expires': '0'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();  // Parse the response as JSON
    })
    .then(data => {
        console.log('Fetched Data:', data);  // Log data for debugging

        // Clear any existing rows in the table
        userList.innerHTML = ''; 

        // Check if data is an array
        if (Array.isArray(data)) {
            data.forEach(user => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>${user.dob}</td>
                    <td>
                        <button class="editBtn" onclick="editUser(${user.id})">Edit</button>
                        <button class="deleteBtn" onclick="deleteUser(${user.id})">Delete</button>
                    </td>
                `;
                userList.appendChild(tr);  // Add the row to the table
            });
        } else {
            console.error("Data is not an array:", data);
        }
    })
    .catch(error => {
        console.error('Error fetching users:', error);  // Log any errors during the fetch
    });
}


// Show Add User Form
addUserBtn.addEventListener('click', () => {
    formTitle.innerText = 'Add User';
    userForm.reset();
    userIdInput.value = '';
    submitBtn.innerText = 'Add User';
    userFormContainer.classList.add('active');
});

// Handle form submission (Add or Update user)
userForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const dob = document.getElementById('dob').value;
    const userId = userIdInput.value;

    const userData = {
        name: name,
        email: email,
        password: password,
        dob: dob
    };

    let method = 'POST';
    let url = apiUrl;

    // If userId exists, it's an update
    if (userId) {
        method = 'PUT';
        url = `${apiUrl}?id=${userId}`;
    }

    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        userFormContainer.classList.remove('active');
        fetchUsers();
    })
    .catch(error => console.log('Error:', error));
});

// Edit User
function editUser(id) {
    fetch(`${apiUrl}?id=${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then(users => {
            // Assuming the response is an array of users, find the user by id
            const user = users.find(u => u.id === id);
            if (user) {
                document.getElementById('name').value = user.name;
                document.getElementById('email').value = user.email;
                document.getElementById('dob').value = user.dob;
                userIdInput.value = user.id;
                formTitle.innerText = 'Edit User';
                submitBtn.innerText = 'Update User';
                userFormContainer.classList.add('active');
            } else {
                console.log('User not found');
            }
        })
        .catch(error => console.log('Error:', error));
}


// Delete User
function deleteUser(id) {
    if (confirm(`Are you sure you want to delete user with ID ${id}?`)) {
        fetch(`${apiUrl}?id=${id}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            fetchUsers();
        })
        .catch(error => console.log('Error:', error));
}

}
// Initial Fetch
fetchUsers();
