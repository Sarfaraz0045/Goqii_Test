<?php
// Include the necessary files
include('../config/database.php');
include('../models/user.php');

// Create User object and fetch all users
$user = new User($conn);
$users = $user->getUsers();  // Fetch all users

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>
<body>

    <div class="container">
        <h1>User Management</h1>
        
        <!-- Add User Button -->
        <div class="add-button-container">
            <button id="addUserBtn">+ Add User</button>
        </div>

        <!-- User List Table -->
        <div class="user-table-container">
            <h2>Users List</h2>
            <table id="userTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Date of Birth</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="userList">
                <?php
                // Loop through the users and create table rows
                foreach ($users as $user) {
                    echo "<tr id='user-{$user['id']}'>";
                    echo "<td>{$user['id']}</td>";
                    echo "<td>{$user['name']}</td>";
                    echo "<td>{$user['email']}</td>";
                    echo "<td>{$user['dob']}</td>";
                    echo "<td><a class='edit_btn' href='#' data-id='{$user['id']}'>Edit</a> | <a class='delt_btn' href='#' data-id='{$user['id']}'>Delete</a></td>";
                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
        </div>

        <!-- Add/Edit User Form -->
        <div class="form-container" id="userFormContainer">
            <h2 id="formTitle">Add User</h2>
            <form action="../api/user.php" method="POST" id="userForm">
                <input type="text" name="name" placeholder="Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="date" name="dob" placeholder="Date of Birth" required>
                <input type="hidden" id="userId">
                <button type="submit" id="submitBtn">Add User</button>
            </form>
        </div>

        <!-- Edit User Form (Initially Hidden) -->
        <div class="form2-container" id="editUserFormContainer" style="display: none;">
            <h2>Edit User</h2>
            <form action="../api/user.php" method="POST" id="editUserForm">
                <input type="text" name="name" id="editName" placeholder="Name" required>
                <input type="email" name="email" id="editEmail" placeholder="Email" required>
                <!-- <input type="password" name="password" id="editPassword" placeholder="New Password"> -->
                <input type="date" name="dob" id="editDob" placeholder="Date of Birth" required>
                <input type="hidden" name="userId" id="editUserId">
                <button type="submit">Update User</button>
                <button type="button" id="closeEditForm">Cancel</button>
            </form>
        </div>

    </div>

    <script>
        // Get references to the button and form container
        const addUserBtn = document.getElementById('addUserBtn');
        const userFormContainer = document.getElementById('userFormContainer');

        // Event listener to show the form when the button is clicked
        addUserBtn.addEventListener('click', function() {
            // Toggle visibility of the form container
            userFormContainer.style.display = 'block';
        });
    </script>

    <script>
        document.getElementById("editUserFormContainer").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form default submission

        let userId = document.getElementById("editUserId").value;
        let formData = {
            id: userId,
            name: document.getElementById("editName").value,
            email: document.getElementById("editEmail").value,
            dob: document.getElementById("editDob").value
        };

        fetch("../api/user.php", {
            method: "PUT",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: new URLSearchParams(formData).toString()
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                // Update the table row dynamically
                let userRow = document.querySelector(`#user-${data.id}`);
                if (userRow) {
                    userRow.children[1].textContent = data.name;
                    userRow.children[2].textContent = data.email;
                    userRow.children[3].textContent = data.dob;
                }

                // Hide the form after updating
                document.getElementById("editUserFormContainer").style.display = "none";

                alert("User updated successfully!");
            } else {
                alert("Update failed! Please try again.");
            }
        })
        .catch(error => console.error("Error:", error));
    });

    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
        // Attach event listener to all "Edit" buttons (Event Delegation)
        document.getElementById("userList").addEventListener("click", function (event) {
            if (event.target.classList.contains("edit_btn")) {
                event.preventDefault(); // Prevent default link behavior

                // Get user data from the clicked row
                let userRow = event.target.closest("tr");
                let userId = event.target.getAttribute("data-id");
                let userName = userRow.children[1].textContent;
                let userEmail = userRow.children[2].textContent;
                let userDob = userRow.children[3].textContent;

                // Fill the form with user data
                document.getElementById("editUserId").value = userId;
                document.getElementById("editName").value = userName;
                document.getElementById("editEmail").value = userEmail;
                document.getElementById("editDob").value = userDob;

                // Show the edit form
                document.getElementById("editUserFormContainer").style.display = "block";
            }
        });

        // Close button functionality
        document.getElementById("closeEditForm").addEventListener("click", function () {
            document.getElementById("editUserFormContainer").style.display = "none";
        });
    });
    </script>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const deleteButtons = document.querySelectorAll('.delt_btn');
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent the default link behavior
                
                const userId = button.getAttribute('data-id');
                const row = document.getElementById('user-' + userId); // Get the table row for this user
                
                if (confirm('Are you sure you want to delete this user?')) {
                    // Send DELETE request to API
                    fetch('../api/user.php', {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ id: userId }) // Send user ID in request body
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.message === "User deleted successfully") {
                            row.remove();
                        } else {
                            alert(data.message); //display the message sent by the server
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error occurred while deleting user.');
                    });
                }
            });
        });
    });
    </script>


</body>
</html>
